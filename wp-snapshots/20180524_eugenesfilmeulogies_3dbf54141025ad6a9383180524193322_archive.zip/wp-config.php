<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'david-site');

/** MySQL database username */
define('DB_USER', 'vortilad');

/** MySQL database password */
define('DB_PASSWORD', '0WYINZkxDJvgykVn');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'tiMcGNxDe0CMq9llxBVSp=6c|;O-Xc0=W mb3+-a)|+lOM:$}lSpb3UG%IR%t!tV');
define('SECURE_AUTH_KEY',  'KUG;4^u@!8jcp$Qa@|a-_`nH~g}RY+|}+E>&_3Uyy{O.A%,- A|Nqx`|N}yeY^pe');
define('LOGGED_IN_KEY',    'MkW$|@g{Le=U=ZIY:ctPv,fr6~<7eN:`$y%,WDb[ZbeWin&>s-q5wuLV x2Q]<9h');
define('NONCE_KEY',        'o|@mKKrEKhQd:-$@::qx^rq$T>tsoW$v>p:,W-QF#k}zm,|x0G=$m+R|4m]N r(Q');
define('AUTH_SALT',        'Y g9U`_ o>.m[(!Pb?Vh}m|G;=VD|q`e~cp+L<3G(I=KpUb+`fxEC!Qb(h!-,XqP');
define('SECURE_AUTH_SALT', '=<3Sv0DZ5<8f|F(q_|pUx#f@wE;b{yJc-1wj72cw5n;hv7QkaDp}vqWR+l, 3)X0');
define('LOGGED_IN_SALT',   '`PH~(zs29|l>>]yC4MUj2H7#RaP(`cD#MIa$/>vbO-`l;U69|9DE^Tl-W9^|uw07');
define('NONCE_SALT',       'L$eMXOo&^pTFQ^+?vw7bGr9>=TNFjy!SAT>,Mj||g{u]{qW8z+.bz/CtY_-,*5T-');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define('WP_CACHE', false);

define('WP_AUTO_UPDATE_CORE', true);
