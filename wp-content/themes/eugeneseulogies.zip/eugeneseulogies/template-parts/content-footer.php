<footer class="footer">
            <div class="footer__container">
                <h6 class="footer__text">Copyright <?php echo date("Y"); ?> <span class="footer__text__name"><?php bloginfo('name')?></span></h6>
            </div>
</footer>